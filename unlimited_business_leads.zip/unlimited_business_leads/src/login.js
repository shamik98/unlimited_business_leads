const api_config = require("./config.json");
const services = require("./services.js");
const helper = require("./helper.js");
const kyubiConfig = require('../public/kyubiSettings.json');

$(document).ready(function () {
    $('#login').click(function (e) {
        e.preventDefault();
        let email = $("#email").val();
        let password = $("#password").val();
        //console.log("login button clicked.");
        chrome.storage.sync.get('subscription', function (res) {
            loginToUbl(email, password, false, res.subscription);
        });
    });
});


const loginToUbl = function (email, password, confirmLogout, subscription) {
    //console.log("loginToUbl function started");
    var errorMessage = 'Please enter valid credentials';

    if ( email.length==0 ) {
        $("#emailid").html("Provide email id please.");
        return;
    }
    
    if ( password.length==0 ) {
        $("#i_password").html("Provide password please.");
        return;
    } else {
        //console.log("mail is valid");
        $("#i_password").html("");
    }

    let data = {
        email: email,
        password: password,
        extensionId: kyubiConfig.extId,
        deviceId: getDeviceId(),
        confirmLogout: confirmLogout,
        subscription: subscription
    };

    let url = api_config.kyubi_base_url + api_config.login_api;

    $(".ubl_overlay").css("display","block");
    $(".ubl_overlay").css("background","rgba(90, 170, 240 , 0.5)");

    services.makeApiRequest('POST', data, url, {})
        .then(res => {
            if (res.status == true && res.token) {
                let store = {
                    user: {
                        email: email,
                        token: res.token
                    }
                }

                services.makeApiRequest('POST', { email: email }, api_config.retrieve_token, {})
                    .then(info => {
                        if (info.status == true && info.userDetails[0].token) {
                            
                            chrome.storage.sync.set({store: store}, function () {
                                chrome.storage.sync.get(['store'], function (res) {
                                    
                                    if (helper.checkAccessToken(res) ) {
                                        chrome.storage.local.set({"rToken" : info.userDetails[0].token, "hunter_key": info.userDetails[0].hunter_key, "tomba_key": info.userDetails[0].tomba_key, "tomba_secret_key": info.userDetails[0].tomba_secret_key});
                                        chrome.storage.local.get(['popupState'], function (result) {
                                            switch ( result.popupState ) {
                                                case "dashboard":
                                                    window.location.href='../dashboard.html' ;
                                                    break;
                                                case "scrapping":
                                                    window.location.href='../scraping.html' ;
                                                    break;
                                                case "congratulations":
                                                    window.location.href='../congratsPage.html' ;
                                                    break;
                                                default:
                                                    window.location.href='../dashboard.html' ;
                                                    break;
                                            }
                                        });
                                    } else {
                                        window.location.href='../login.html' ;
                                    }
                                });
                            });
                        }
                    })
                    .catch(err => {
                        console.log("err :: ", JSON.stringify(err, null, 4));
                    });
            } else if (res.status && !res.token) {
                const ConfirmMsg = confirm(res.message);
                if (ConfirmMsg == true) {
                    loginToUbl(email, password, true, subscription);
                } else {
                    $(".ubl_overlay").css("display","none");
                    $(".ubl_errMsglogin").removeAttr("style");
                    $('.ubl_errMsglogin').html(errorMessage);
    
                    setTimeout(function () {
                        $(".ubl_errMsglogin").fadeOut();
                    }, 4000);
                }
              } else {
                $(".ubl_overlay").css("display","none");
                $(".ubl_errMsglogin").removeAttr("style");
                $('.ubl_errMsglogin').html(errorMessage);

                setTimeout(function () {
                    $(".ubl_errMsglogin").fadeOut();
                }, 4000);
            }
        })
        .catch(err => {
            console.log("err :: ", JSON.stringify(err, null, 4));
        });
}

const getDeviceId = function () {
    var navigator_info = window.navigator;
    var screen_info = window.screen;
    var uid = navigator_info.mimeTypes.length;
    uid += navigator_info.userAgent.replace(/\D+/g, '');
    uid += navigator_info.plugins.length;
    uid += screen_info.height || '';
    uid += screen_info.width || '';
    uid += screen_info.pixelDepth || '';
  
    return uid;
};