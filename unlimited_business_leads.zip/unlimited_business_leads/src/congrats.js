$(document).ready(function(){
    
  $("#homeBtnn").click(function(){
    console.log("dashboard....");
    chrome.storage.local.set({popupState: "dashboard"});
    chrome.runtime.sendMessage({msg : "clearBadge"});
    chrome.tabs.reload();
    window.location.href = "../dashboard.html";
  })

});