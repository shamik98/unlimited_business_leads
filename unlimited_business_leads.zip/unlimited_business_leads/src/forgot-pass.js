const api_config = require("./config.json");
const services = require("./services.js");
const kyubiConfig = require('../public/kyubiSettings.json');
$(document).ready(function() {
    //console.log(url.BASE_URL);
    $("#forgotPass").click(function(e) {
        e.preventDefault();
        // alert("on submit comming");
        var email = $("#email").val();
        var mailregex = /^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$/;
        if(email.length==0){
            $(".cf_errMsg").html("Provide your email id please.");
        }
        else if (!mailregex.test(email)) {
            $(".cf_errMsg").html("Put valid email id please.");
        }
        else {
            forgot(email);
        }
    });
});

const forgot = function(email) {

    let data = {
        email: email,
        extId: kyubiConfig.extId
    };

    let url = api_config.kyubi_base_url + api_config.forgot_password_api;

    services.makeApiRequest('POST', data, url, {})
        .then(info => {
            if (info.status) {
                window.location.href = "../confirmation.html";
            } else {
                $("#wrongmail").html(info.message);
            }
        })

}