const states = require("./states.json");
const testDataJson = require("./testData.json");
const services = require("./services.js");
const api_cofig = require("./config.json");
const kyubiConfig = require('../public/kyubiSettings.json');

require("jquery-toast-plugin");

$(document).ready(function() {

    document.addEventListener('DOMContentLoaded', function () {
        chrome.runtime.sendMessage({ msg: "DOMContentLoaded"});
    })

    let csvExportRequired = false;

    let resultPickCount = 0,
        startpos = 0,
        TotalCount = 0,
        resultRowCount = 1,
        searchPosition = 0,
        b,
        searchKey = "",
        storeInfoPost = [],
        customTimeOut = "",
        nextPageTimeout = "",
        get_hunter_data = "",
        get_tomba_data = "",
        domain_name = "",
        hunter_key = "",
        tomba_key = "",
        tomba_secret_key = "";

    let url = location.href.split('/');
    if ((url[2] == 'www.google.com' || url[2] == 'www.google.co.in') && url[3].split('?')[0] == 'search' && url[3].split('?')[1].split('=')[0] !== 'q') {
        $.toast({
            text: kyubiConfig.appName + " has access to this page. Do you wanna get leads now?", // Text that is to be shown in the toast
            heading: 'Get your leads now!', // Optional heading to be shown on the toast
            icon: 'info', // Type of toast icon
            showHideTransition: 'fade', // fade, slide or plain
            allowToastClose: true, // Boolean value true or false
            hideAfter: false, // false to make it sticky or number representing the miliseconds as time after which toast needs to be hidden
            stack: false, // false if there should be only one toast at a time or a number representing the maximum number of toasts to be shown at a time
            position: 'top-center', // bottom-left or bottom-right or bottom-center or top-left or top-right or top-center or mid-center or an object representing the left, right, top, bottom values
            textAlign: 'left',  // Text alignment i.e. left, right or center
            loader: true,  // Whether to show loader or not. True by default
            loaderBg: '#9EC600',  // Background color of the toast loader
            bgColor: '#33691e',
            textColor : '#fff'
        });
    }

    chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
        switch ( request.msg ) {
            case "start":
                startScrapping(request.formData);
                break;
            case "stop":
                stopScraping(request.formData);
                break;
            case "sendTestData":
                sendTestDataToWebhook(request.formData.url);
                break;
            case "hunter_details":
                get_hunter_data = request.hunter_data.get_hunter_data;
                hunter_key = request.hunter_data.hunter_key;
                break;
            case "tomba_details":
                get_tomba_data = request.tomba_data.get_tomba_data;
                tomba_key = request.tomba_data.tomba_key;
                tomba_secret_key = request.tomba_data.tomba_secret_key;
                break;
            default:
                break;
        }
    });
    

    function startScrapping( data ){
        
        // Promise
        
        resultRowCount = document.getElementsByClassName("NwqBmc").length;
        b = document.getElementsByClassName("NwqBmc");

        searchKey = $("input[aria-label='Search for a service']").val();
        //console.log(searchKey);
        searchPosition = 1;

        picData(0, data);
    }

    function stopScraping() {
        
        TotalCount = 0;

        clearTimeout(customTimeOut);
        clearTimeout(nextPageTimeout);
        
        if ( csvExportRequired ) {
            exportCsv();
            chrome.runtime.sendMessage({msg : "Complete"});
        } else {
            chrome.runtime.sendMessage({msg : "Complete"});
        }
    }

    // this method is gonna send a test data
    // depending upon hunter data option selected it'll send different test data
    function sendTestDataToWebhook ( webhookUrl ) {
        services.makeApiRequest('POST', ((get_hunter_data && hunter_key) || (get_tomba_data && tomba_key && tomba_secret_key)) ? testDataJson.with_email_data : testDataJson.without_email_data, webhookUrl, {})
            .then(info => {
               // console.log("info :: ", JSON.stringify(info, null, 4));
                if ( info.status == false || info == "Accepted" ){
                    chrome.runtime.sendMessage({msg : "error"});
                }  else {
                    chrome.runtime.sendMessage({msg : "success"});
                }
            })
            .catch(err => {
               // console.log("err :: ", JSON.stringify(err, null, 4));
            });
    }

    function nextPage( dataProcessType ) {
        nextClicked = true;
        //$('#pnnext')[0].click();
        document.querySelectorAll('[aria-label="Next"]')[0].click();

        nextPageTimeout = setTimeout(() => {
            nextClicked = false;
            resultRowCount = document.getElementsByClassName("NwqBmc").length;
            b = document.getElementsByClassName("NwqBmc");

            resultPickCount = 0;
            startpos = 0;
            picData(startpos, dataProcessType);
            
        }, 10000);
    }    

    function playWithDataWhenReady ( dataProcessType, businessInfoPost ) {
        if ( dataProcessType.how_proceed == 'csv' ) {
            resultPickCount++;
            startpos++;
            TotalCount++;
            storeInfoPost.push(businessInfoPost);

            csvExportRequired = true;
            
            chrome.runtime.sendMessage({type: "setCount", count: TotalCount});

            dataPickStatus = true;

            picData(startpos, dataProcessType);
            
        } else {
            services.makeApiRequest('POST', businessInfoPost, dataProcessType.url, {})
                .then(info => {

                    if ( info.status ) {
                        csvExportRequired = false;
                        resultPickCount++;
                        startpos++;
                        TotalCount++;

                        chrome.runtime.sendMessage({type: "setCount", count: TotalCount});

                        dataPickStatus = true;

                        picData(startpos, dataProcessType);
                    }
                                        
                })
                .catch(err => {
                    resolve ({success : false});
                });

        }
    }

    function sendMessagePromise(item) {
        return new Promise((resolve, reject) => {
            chrome.runtime.sendMessage(item, response => {
                if(response.emails.length) {
                    resolve({status: true, emails: response.emails});
                } else {
                    resolve({status: false});
                }
            });
        });
    }

    function picData(startpos, dataProcessType) {

        if ( startpos < resultRowCount && b[resultPickCount] !== undefined) {
            
            let businessInfoPost = {};

            if ($(b[resultPickCount]).find('span.uDmIZc').length == 0) {
                businessInfoPost.a_searchPosition = searchPosition++;
                businessInfoPost.b_adStatus = 'No Ad';
            } else {
                businessInfoPost.a_searchPosition = 'N/A';
                businessInfoPost.b_adStatus = 'Ad';
            }


            /* =================== RESULT LIST CLICK ==================== */
            b[resultPickCount].click();

            customTimeOut = setTimeout(() => {

                /* =================== AFTER CLICK ==================== */
                dataPickStatus = false;

                businessInfoPost.c_name = document.getElementsByClassName("rgnuSb tZPcob")[0].innerText.replace(/[,]/g, '').replace(/[-]/g, '').replace(/[|]/g, '');

                /* ======================== Description ========================= */
                let desc = document.getElementsByClassName("kFBMHc")[0].innerText.replace(/[•]/g, '');
                if (desc == undefined || desc == "") {
                    businessInfoPost.d_description = "N/A";
                } else {
                    businessInfoPost.d_description = desc
                }
                /* ======================================================= */


                /* ======================== Rating ========================= */
                let rating = document.querySelectorAll(".eyxqWe .rGaJuf")[0].innerText;
                if (rating == undefined || rating == "") {
                    businessInfoPost.e_rating = "N/A";
                } else {
                    businessInfoPost.e_rating = rating;
                }
                /* ======================================================= */


                /* ======================== Reviews ========================= */
                let review = document.querySelectorAll(".eyxqWe .leIgTe")[0].innerText.replace(/[()]/g, '');
                if (review == undefined || review == "") {
                    businessInfoPost.f_reviews = "N/A";
                } else {
                    businessInfoPost.f_reviews = review.split(" ")[0].replace(/\,/g, '');
                }
                /* ======================================================= */


                /* ======================== Phone ========================= */
                
                let phone = document.getElementsByClassName("SROCu QvSLnc")[1].innerText.includes('Open') ? document.getElementsByClassName("SROCu QvSLnc")[2].innerText.replace(/\D/g, "") : document.getElementsByClassName("SROCu QvSLnc")[1].innerText.replace(/\D/g, "");
                let phone2 = document.getElementsByClassName("SROCu QvSLnc")[1].innerText.includes('Open') ? document.getElementsByClassName("SROCu QvSLnc")[3].innerText.replace(/\D/g, "") : document.getElementsByClassName("SROCu QvSLnc")[1].innerText.replace(/\D/g, "");
                let checkCovid19 = document.querySelectorAll('.UDLlPd')[0];
                
                // if (phone == undefined || phone == "") {
                //     businessInfoPost.g_phone = "N/A";
                // } else {
                //     businessInfoPost.g_phone = phone;
                // }

                if (checkCovid19 !== undefined) {
                    //console.log("phone2 ->", phone2);
                    if (phone2 != undefined || phone2 != "") {
                        businessInfoPost.g_phone = phone2;
                    } else {
                        businessInfoPost.g_phone = "N/A";
                    }
                } else {
                    if (phone != undefined || phone != "") {
                        businessInfoPost.g_phone = phone;
                    } else {
                        businessInfoPost.g_phone = "N/A";
                    }   
                }

                /* ======================================================= */

                /* ======================== Address ========================= */
                let address = document.getElementsByClassName("fccl3c")[0];

                //console.log("address ->",address);
                //console.log("type of address ->", typeof address);

                if (address !== undefined)
                {

                    address = document.getElementsByClassName("fccl3c")[0].innerText;
                    let foundUAE = address.search("United Arab Emirates");

                    let addressLength = address.split(",").length;
                    //let addressPropSplit = address.split(",")[addressLength - 2];
                    let addressPropSplit = address.split(",");
                    //let addressPropSplit = address.split(",");
                    //console.log("addressPropSplit ->", addressPropSplit);

                    if (address == undefined || address == "") {
                        businessInfoPost.h_streetAddress = "N/A";
                        businessInfoPost.i_city = "N/A";
                        businessInfoPost.j_state = "N/A";
                        businessInfoPost.k_zip = "N/A";
                    } else if (foundUAE < 0 && states[addressPropSplit[2].trim().split(" ")[0]] !== undefined) {
                        // let stAddress = "";
                        // for (let i = 0; i <= addressLength - 4; i++) {
                        //     if (i > 0) {
                        //         stAddress += ', ' + address.split(",")[i];
                        //     } else {
                        //         stAddress = address.split(",")[i];
                        //     }
                        // }

                       // console.log('addressPropSplit[2].trim().split(" ")[0] ->', addressPropSplit[2].trim().split(" ")[0]);

                        businessInfoPost.h_streetAddress = addressPropSplit[0].replace(/\,/g, ' ');
                        //businessInfoPost.h_streetAddress = sdocument.getElementsByClassName("fccl3c")[0].innerText.split(",")[0];

                        businessInfoPost.i_city = addressPropSplit[2].trim().split(" ")[0] == "DC" ? "Washington D.C." : addressPropSplit[1].trim();
                        businessInfoPost.j_state = addressPropSplit[2].trim().split(" ")[0] == "DC" ? "Washington D.C." : states[addressPropSplit[2].trim().split(" ")[0]];

                        businessInfoPost.k_zip = addressPropSplit[2].trim().split(" ")[1];
                    } else if (foundUAE > 0) {
                        addressPropSplit = address.split(" - ");
                        addressLength = addressPropSplit.length;
                        let stAddress = "";
                        for (let i = 0; i <= addressLength - 3; i++) {
                            if (i > 0) {
                                stAddress += ', ' + addressPropSplit[i];
                            } else {
                                stAddress = addressPropSplit[i];
                            }
                        }

                        businessInfoPost.h_streetAddress = stAddress.replace(/\,/g, ' ');

                        businessInfoPost.i_city = addressPropSplit[addressLength - 2];
                        businessInfoPost.j_state = "N/A";
                        businessInfoPost.k_zip = "N/A";
                    } else {
                        businessInfoPost.h_streetAddress = address.replace(/\,/g, '');
                        businessInfoPost.i_city = "N/A";
                        businessInfoPost.j_state = "N/A";
                        businessInfoPost.k_zip = "N/A";
                    }
                }
                else {
                    businessInfoPost.h_streetAddress = "N/A";
                    businessInfoPost.i_city = "N/A";
                    businessInfoPost.j_state = "N/A";
                    businessInfoPost.k_zip = "N/A";
                }
                

                
                /* ======================================================= */

                /* ======================== Website ========================= */

                if (document.querySelectorAll("#overview-panel")[0].getElementsByTagName('div')[33].innerText.includes('.com') ? document.querySelectorAll("#overview-panel")[0].getElementsByTagName('div')[33].innerText : document.querySelectorAll("#overview-panel")[0].getElementsByTagName('div')[15].innerText === undefined) 
                {

                    businessInfoPost.l_website = 'N/A';
                } else {
                    let website = document.querySelectorAll(".Gx8NHe")[0] ? document.querySelectorAll(".Gx8NHe")[0].innerText : "N/A";
                    if (website == undefined || website == "" || website == "#") {
                        businessInfoPost.l_website = 'N/A';
                    } else {
                        businessInfoPost.l_website = website;
                        domain_name = website.replace('http://','').replace('https://','').split(/[/?#]/)[0];
                    }
                }
                /* ======================================================= */

                /* ========================= Email ======================= */

                if ( get_hunter_data && hunter_key && businessInfoPost.l_website !== 'N/A') {
                    
                    sendMessagePromise({ type: "getHunterEmailDetails", domain: domain_name })
                        .then(function(info){
                    // services.makeApiRequest('GET', '', url, {})
                    //     .then(info => {
                        if ( info.status ) {
                            info.emails.forEach(function ( element, index) {
                                businessInfoPost['email_' + (index+1)] = element.value;
                                businessInfoPost['fname_' + (index+1)] = element.first_name ? element.first_name : '';
                                businessInfoPost['lname_' + (index+1)] = element.last_name ? element.last_name : '';
                            
                                if ( index == info.emails.length-1 ) {
                                    playWithDataWhenReady( dataProcessType, businessInfoPost );
                                }
                            });
                        } else {
                            playWithDataWhenReady( dataProcessType, businessInfoPost );
                        }
                        });
                } else if ( get_tomba_data && tomba_key && tomba_secret_key && businessInfoPost.l_website !== 'N/A') {

                    sendMessagePromise({ type: "getTombaEmailDetails", domain: domain_name })
                    .then(function(res){
                        if ( res.status ) {
                            res.emails.forEach(function ( element, index) {
                                businessInfoPost['email_' + (index+1)] = element.email;
                                businessInfoPost['fname_' + (index+1)] = element.first_name ? element.first_name : '';
                                businessInfoPost['lname_' + (index+1)] = element.last_name ? element.last_name : '';
                            
                                if ( index == res.emails.length-1 ) {
                                    playWithDataWhenReady( dataProcessType, businessInfoPost );
                                }
                            });
                        } else {
                            playWithDataWhenReady( dataProcessType, businessInfoPost );
                        }
                    });
                } else {
                    playWithDataWhenReady( dataProcessType, businessInfoPost );
                }

                /* ======================================================= */

            }, 2000);

            
        //} else if ( !$('#pnnext').length ) {

        } else if (!document.querySelectorAll('[aria-label="Next"]').length) {

            clearTimeout(customTimeOut);
            clearTimeout(nextPageTimeout);

            if (csvExportRequired) {
                exportCsv();
                chrome.runtime.sendMessage({msg : "Complete"});
            } else {
                chrome.runtime.sendMessage({msg : "Complete"});
            }
        } else {
            nextPage( dataProcessType );
        }

    }

    function exportCsv() {
        
        clearTimeout(customTimeOut);

        if (( get_hunter_data && hunter_key ) || ( get_tomba_data && tomba_key && tomba_secret_key )) {
            storeInfoPost.unshift(["Search Position", "Ad status", "Business name", "Description", "Rating", "Total reviews", "Phone number", "Street address", "City", "State", "Zip", "Website", "email_1", "fname_1", "lname_1", "email_2", "fname_2", "lname_2", "email_3", "fname_3", "lname_3", "email_4", "fname_4", "lname_4", "email_5", "fname_5", "lname_5", "email_6", "fname_6", "lname_6", "email_7", "fname_7", "lname_7", "email_8", "fname_8", "lname_8", "email_9", "fname_9", "lname_9", "email_10", "fname_10", "lname_10"]);
        } else {
            storeInfoPost.unshift(["Search Position", "Ad status", "Business name", "Description", "Rating", "Total reviews", "Phone number", "Street address", "City", "State", "Zip", "Website"]);
        }
        
        let jsonObject = JSON.stringify(storeInfoPost);
        var csv = ConvertToCSV(jsonObject);


        let blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
        if (navigator.msSaveBlob) {
            // IE 10+
            navigator.msSaveBlob(blob, searchKey);
        } else {
            let link = document.createElement("a");
            if (link.download !== undefined) {
                // feature detection
                // Browsers that support HTML5 download attribute
                let url = URL.createObjectURL(blob);
                link.setAttribute("href", url);
                link.setAttribute("download", searchKey + '.csv');
                link.style.visibility = "hidden";
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            }
        }
    }

    function ConvertToCSV(objArray) {

        var array = typeof objArray != 'object' ? JSON.parse(objArray) : objArray;
        var str = '';

        for (let i = 0; i < array.length; i++) {
            let line = "";
            for (let index in array[i]) {
                if (line !== "") line += ",";
                line += array[i][index];
            }
            str += line + "\r\n";
        }
        return str;

    }

});