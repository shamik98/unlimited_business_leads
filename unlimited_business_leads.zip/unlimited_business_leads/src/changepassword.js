const api_config = require("./config.json");
const helper = require("./helper.js");
const services = require("./services.js");
const kyubiConfig = require('../public/kyubiSettings.json');

$(document).ready(function() {
    $("#submitNewPassword").click(function(e) {
        e.preventDefault();
        
        let old_password = $("#password").val();
        let new_password = $("#newpassword").val();
        let confirm_password = $("#repeatnewpassword").val();
        if (old_password.length == 0) {
            //console.log("oldlength is 0");
            $("#errormsg1").html("Please provide your old password.");
            return
        } else {
            $("#errormsg1").html("");
        }

        if (new_password.length == 0) {
            // //console.log("oldlength is 0");
            $("#errormsg2").html("Please provide a new password.");
            return
        } else {
            $("#errormsg2").html("");
        }

        if (old_password === new_password) {
            $("#errormsg2").html("Old password and new password should not be same.");
            return
        } else {
            $("#errormsg2").html("");
        }

        if (new_password !== confirm_password) {
            $("#errormsg3").html("New password and confirm new password should be same.");
            
            return
        } else {
            $("#errormsg3").html("");
        }

        // Getting accessToken from localStorage
        // Enable when login is being pushed to git
        chrome.storage.sync.get(["store"], function(res) {
            // console.log("res :::: from changePassword :::: ", res);
            if (helper.checkAccessToken(res)) {
                updatePwd( res.store.user.token, res.store.user.email, old_password, new_password, confirm_password );
            } else {
                //console.log("No access token found");
                $("#formContent").html("No access token found");
                $("#formContent").show();
                setTimeout(() => {
                    $("#formContent").hide();
                }, 3000);
            }
        });
    });
});

// Sending update password request to the server

const updatePwd = function( token,email, oldPwd, newPwd, cnewPwd) {

    $(".sentStatus").css("display","none");
    $(".sendingStatus").css("display","inline-block");

    let sendToUrl = api_config.kyubi_base_url + api_config.change_password_api;
    let headers = {
        'Authorization': "KYUBI_" + token
    };

    let data = { 
        extensionId : kyubiConfig.extId,
        email: email,
        password: oldPwd,
        confirmNewPassword:cnewPwd,
        newPassword: newPwd 
    };

    services.makeApiRequest('POST', data, sendToUrl, headers)
        .then(info => {
            if (info.status == true) {
                $(".sendingStatus").css("display","none");
                $(".sentStatus").css("display","inline-block");
                chrome.runtime.sendMessage({msg : "reload"});
                setTimeout(function () {
                    window.location.href='../dashboard.html' ;
                }, 2000);
            } else {
                $(".sendingStatus").css("display","none");
                $(".sentStatus").css({"display":"inline-block", "color" : "#F14336"});
                $(".sentStatus").html(`<img src="./images/closeRed.svg" alt="">` + res.message);
            }
        })
        .catch(err => {
            console.log("err :: ", JSON.stringify(err, null, 4));
        });

}