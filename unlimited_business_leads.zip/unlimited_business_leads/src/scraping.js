$(document).ready(function(){
    $("#stop").click(function(){
        console.log("congratulations....");
        chrome.storage.local.set({popupState: "congratulations"});
        window.location.href = "../congratsPage.html";
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
          chrome.tabs.sendMessage(tabs[0].id,{ msg: "stop"});
        });
    });

    chrome.runtime.onMessage.addListener(
        function(message, sender, sendResponse) {
            $("#count").html(message.count);
            if(message.msg == "Complete"){
                console.log("congratulations....   ");
                window.location.href = "../congratsPage.html";
            }
        }
    );
});