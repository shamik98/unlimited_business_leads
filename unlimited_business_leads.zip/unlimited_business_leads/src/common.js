const services = require("./services.js");
const api_config = require("./config.json");
const helper = require("./helper.js");
const kyubiConfig = require('../public/kyubiSettings.json');

let rToken = '';

$(document).ready(function () {

  chrome.storage.local.get(['get_hunter_data', 'hunter_key', 'get_tomba_data', 'tomba_key', 'tomba_secret_key', 'rToken', 'webhook_url', 'popupState'], function (result) {
        
    rToken = result.rToken;

    if ( result.hunter_key ) {
      $(".hunterApiArea").show();
      if ( result.get_hunter_data == true ) {
        $("#hunterApiUse").attr('checked', 'true');
        
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
          // console.log("tabs : ",tabs);
          chrome.tabs.sendMessage(tabs[0].id, { msg: "hunter_details", hunter_data : result });
        });
      } else {
        $("#hunterApiUse").removeAttr('checked');
      }
    } else {
      $(".hunterApiArea").css("display", "none");
    }
    
    $("#hunter_key_input").val(result.hunter_key);

    if ( result.tomba_key && result.tomba_secret_key ) {
      $(".tombaApiArea").show();
      if ( result.get_tomba_data == true ) {
        $("#tombaApiUse").attr('checked', 'true');
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
          // console.log("tabs : ",tabs);
          chrome.tabs.sendMessage(tabs[0].id, { msg: "tomba_details", tomba_data : result });
        });
      } else {
        $("#tombaApiUse").removeAttr('checked');
      }
    } else {
      $(".tombaApiArea").css("display", "none");
    }
    
    $("#tomba_key_input").val(result.tomba_key);
    $("#tomba_secret_key_input").val(result.tomba_secret_key);

    $("#url").val(result.webhook_url);
  });

  $('title').text(kyubiConfig.appName);

  $('#logout').on('click', function(e) {
    e.preventDefault();

    chrome.storage.sync.get(['store'], function (res) {
      if (helper.checkAccessToken(res) ) {
        logoutExt(
          kyubiConfig.clearSubscriptionObjectURL,
          res.store.user.email,
          kyubiConfig.extId
        );
      }
    });

    
  });

  function logoutExt(logoutURL, email, extensionId) {
    fetch(logoutURL, {
      method: 'POST', // *GET, POST, PUT, DELETE, etc.
      mode: 'cors', // no-cors, cors, *same-origin
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
        // "Authorization": "KYUBI_"+ token
        // 'Access-Control-Allow-Origin': "*"
      },
      body: JSON.stringify({ email: email, extId: extensionId }), // body data type must match "Content-Type" header
    })
      .then((response) => response.json())
      .then((res) => {
        chrome.storage.sync.remove(('store'), function() {
          //console.log("Or Its clicking here");
          window.location.replace("../login.html");
        });
      })
      .catch((err) => {
        chrome.storage.sync.remove(('store'), function() {
          //console.log("Or Its clicking here");
          window.location.replace("../login.html");
        });
      });
  }

  $("#cancelAcnt").click(function(e){
    e.preventDefault();
    $(".calncelAc").remove();
    $('body').append(
      `<div class="calncelAc">
      <button class="close" id="close"><img src="images/close-white.svg" alt=""></button>
      <p>
          To cancel your account please email us at<br><a href="mailto:`+ kyubiConfig.mailTo +`">`+ kyubiConfig.mailTo +`</a>
      </p>
      </div>`);
      $(".calncelAc").css("display", "block");
  });

  if(kyubiConfig.mailTo == null || kyubiConfig.mailTo == ""){
    $("#cancelAcnt").hide();
  }else{
    $("#cancelAcnt").show();
  }

  $("#addOrUpdateHunterKey").click(function () {
    $(".sentStatus").css("display","none");
    $(".sendingStatus").css("display","inline-block");

    let data = {
      token: rToken,
      hunter_key: $("#hunter_key_input").val()
    };

    console.log(JSON.stringify(data, null, 4));

    services.makeApiRequest('POST', data, api_config.add_key, {})
      .then(info => {
        
        if(info.status == true) {
          $("#hunter_key_input").val(data.hunter_key);
          chrome.storage.local.set({hunter_key: data.hunter_key});
          $(".sendingStatus").css("display","none");
          $(".sentStatus").css("display","inline-block");

        } else {
          $(".sendingStatus").css("display","none");
          $(".sentStatus").css({"display":"inline-block", "color" : "#F14336"});
          $(".sentStatus").html(`<img src="./images/closeRed.svg" alt=""> Error`);
        }
      })
      .catch(err => {
          console.log("err :: ", JSON.stringify(err, null, 4));
      });
  });

  $("#addOrUpdateTombaKey").click(function () {
    $(".sentStatus").css("display","none");
    $(".sendingStatus").css("display","inline-block");

    let data = {
      token: rToken,
      tomba_key: $("#tomba_key_input").val(),
      tomba_secret_key: $("#tomba_secret_key_input").val()
    };

    services.makeApiRequest('POST', data, api_config.add_key, {})
      .then(info => {
        
        if(info.status == true) {
          $("#tomba_key_input").val(data.tomba_key);
          $("#tomba_secret_key_input").val(data.tomba_secret_key);
          chrome.storage.local.set({tomba_key: data.tomba_key, tomba_secret_key: data.tomba_secret_key});
          $(".sendingStatus").css("display","none");
          $(".sentStatus").css("display","inline-block");

        } else {
          $(".sendingStatus").css("display","none");
          $(".sentStatus").css({"display":"inline-block", "color" : "#F14336"});
          $(".sentStatus").html(`<img src="./images/closeRed.svg" alt=""> Error`);
        }
      })
      .catch(err => {
          console.log("err :: ", JSON.stringify(err, null, 4));
      });
  });

  $(document).on('click' , "#close" , function(e){
    e.preventDefault();
    $(".calncelAc").fadeOut();
    setTimeout(function(){
    $(".calncelAc").remove();
    },400);
  });

  $(".test_data").css("display", "none");

  $('#webhook').click(function(){
    // console.log("is checked : ",$('#webhook').is(":checked"));
    if($('#webhook').is(":checked"))  {
      $(".test_data").show();
    }
  })

  $('#csv').click(function(){
    // console.log("is checked : ",$('#csv').is(":checked"));
    if($('#csv').is(":checked"))  {
      $(".test_data").css("display", "none");
    } 
  })
      

  $("#proceed").click(async function(){
    // console.log("Form Submit");
    const formData = await formDatatoJson($("#settingsForm").serializeArray());
    if(formData.how_proceed == "webhook" && formData.url == ""){
        $("#url_error").text("Please enter the URL");
    } else {
      $("#url_error").text("");
      chrome.storage.local.set({popupState: "scrapping", webhook_url: formData.url});
      console.log("scrapping....");
      setTimeout(function(){
        window.location.href = "../scraping.html";
      },200);
      chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        console.log("tabs : ",tabs);
        chrome.tabs.sendMessage(tabs[0].id, { msg: "start", formData : formData });
      });
    }
  });

  $("#test_data").click(async function(){ 
    const formData = await formDatatoJson($("#settingsForm").serializeArray());
    if(formData.how_proceed == "webhook" && formData.url == ""){
      $("#url_error").text("Please enter the URL");
    } else {
      $("#url_error").text("");
      $(".sendingStatus").css("display","inline-block");
      $("#test_data").css("display","none");
      chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        chrome.tabs.sendMessage(tabs[0].id, { msg: "sendTestData", formData : formData });
      })
    }
  })
  
  chrome.runtime.onMessage.addListener(
    function(message, sender, sendResponse) {
      console.log("message :: ", message);
      switch ( message.msg ) {
        case "success":
          $(".sendingStatus").css("display","none");
          $(".sentStatus").css("display","inline-block");
          break;
        case "error":
          $(".sendingStatus").css("display","none");
          $(".sentStatus").css({"display":"inline-block", "color":"#F14336"});
          $(".sentStatus").html(`<img src="./images/closeRed.svg" alt=""> Not Sent`);
          break;

      }
  });

  const formDatatoJson = async function (serializedArray) {
    var result = {};
    $.each(serializedArray, function () {
        result[this.name] = this.value;
    });
    return await result;
  };

  $(".homeBtn").click(function(){
    chrome.runtime.sendMessage({msg : "reload"});
    chrome.runtime.sendMessage({msg : "clearBadge"});
    setTimeout(function(){
      window.location.href = "../dashboard.html";
    },200);
  })

  // Menu
  $(".hamMenu").click(function () {
    if($(".rightPanelDrawer").hasClass("close")){
      $(".rightPanelDrawer").removeClass("close");
    }
  });

  $(".clocseMenu").click(function(){
    $(".rightPanelDrawer").addClass("close");
  })
  // Menu --- END

  // Hunter data option
  $("#hunterApiUse").change(function () {
    if ( $(this).prop("checked") == true && $("#tombaApiUse").prop("checked") == false){
      console.log("inside if");
      chrome.storage.local.set({get_hunter_data: true, get_tomba_data: false});
    } else if ($(this).prop("checked") == true && $("#tombaApiUse").prop("checked") == true) {
      console.log("inside else if");
      $("#tombaApiUse").prop("checked", false); 
      chrome.storage.local.set({get_hunter_data: true, get_tomba_data: false});
    } else {
      console.log("inside else");
      chrome.storage.local.set({get_hunter_data: false});
    }
  });
  // Hunter data option end

  // Tomba data option
  $("#tombaApiUse").change(function () {
    if ( $(this).prop("checked") == true && $("#hunterApiUse").prop("checked") == false){
      chrome.storage.local.set({get_hunter_data: false, get_tomba_data: true});
    } else if ($(this).prop("checked") == true && $("#hunterApiUse").prop("checked") == true) {
      $("#hunterApiUse").prop("checked", false); 
      chrome.storage.local.set({get_hunter_data: false, get_tomba_data: true});
    } else {
      chrome.storage.local.set({get_tomba_data: false});
    }
  });
  // Tomba data option end

  // Show or hide footer
  if (kyubiConfig.footer.showFooter) {
    // console.log("kyubiConfig.footer.showFooter true : ", kyubiConfig.footer.showFooter);
    if (kyubiConfig.footer.poweredBy.willBeDisplayed) {
      if (kyubiConfig.footer.poweredBy.url) {
        $("#poweredby").attr("href", kyubiConfig.footer.poweredBy.url);
        if (kyubiConfig.footer.poweredBy.url == "#")
          $("#poweredby").removeAttr("target");
      } else {
        $("#poweredby").attr("href", "");
        $("#poweredby").removeAttr("target");
      }
      if (kyubiConfig.footer.poweredBy.label)
        $("#poweredby").html(kyubiConfig.footer.poweredBy.label);
      else {
        $("#poweredby").html("");
        $("#and").hide();
      }
    } else {
      $("#poweredby").attr("href", "");
      $("#poweredby").html("");
      $("#and").hide();
    }

    if (kyubiConfig.footer.partnership.willBeDisplayed) {
      if (kyubiConfig.footer.partnership.url) {
        $("#partnership").attr("href", kyubiConfig.footer.partnership.url);
        if (kyubiConfig.footer.partnership.url == "#")
          $("#partnership").removeAttr("target");
      } else {
        $("#partnership").attr("href", "");
        $("#partnership").removeAttr("target");
      }
      if (kyubiConfig.footer.partnership.label)
        $("#partnership").html(kyubiConfig.footer.partnership.label);
      else {
        $("#partnership").html("");
        $("#and").hide();
      }
    } else {
      $("#partnership").attr("href", "");
      $("#partnership").html("");
      $("#and").hide();
    }

    if (kyubiConfig.footer.officialGroup.willBeDisplayed) {
      if (kyubiConfig.footer.officialGroup.url) {
        $("#group").attr("href", kyubiConfig.footer.officialGroup.url);
      } else {
        $("#group").attr("href", "");
        $("#group").html("");
      }
    } else {
      $("#group").attr("href", "");
      $("#group").html("");
    }

    if (kyubiConfig.footer.chatSupport.willBeDisplayed) {
      if (kyubiConfig.footer.chatSupport.url) {
        $("#chat").attr("href", kyubiConfig.footer.chatSupport.url);
      } else {
        $("#chat").attr("href", "");
        $("#chat").html("");
      }
    } else {
      $("#chat").attr("href", "");
      $("#chat").html("");
    }

    if (kyubiConfig.youtubeLink) {
      if (kyubiConfig.youtubeLink) {
        $("#training").attr("src", kyubiConfig.youtubeLink);
      } else {
        $("#training").attr("src", "");
        $("#training").html("");
      }
    } else {
      $("#training").attr("src", "");
      $("#training").html("");
    }
  } else {
    $(".footer").html("");
  }

  // Show diffrent background
  $(".authScreen").css("background-image", "url("+chrome.runtime.getURL( kyubiConfig.logo.background_image )+")");

  // Show or hide loader
  if (kyubiConfig.loader.preLoader) {
    $('#loading').attr('src', kyubiConfig.loader.preLoader);
  } else {
    $('#loading').attr('src', './images/blue-spinner.gif');
  }

  // Show or hide loader
  if (kyubiConfig.loader.customLoader) {
    $('#scrapping').attr('src', kyubiConfig.loader.customLoader);
  } else {
    $('#scrapping').attr('src', './images/Loading.gif');
  }

  // Show logo
  if (kyubiConfig.logo.primary_logo) {
    $('#primaryLogo').attr('src', kyubiConfig.logo.primary_logo);
  }

  // Signup url
  if (kyubiConfig.signupURL) {
    $('#signupLink').attr("href", kyubiConfig.signupURL);
  } else {
    $('#signup').html("");
  }

  // Training Video URl
  if (kyubiConfig.youtubeLink) {
    $('#trainingVideo').show();
    $('#trainingVideoLink').attr('src', kyubiConfig.youtubeLink);
  } else {
    $('#trainingVideo').show();
  }
  
  chrome.storage.sync.get(['store'], function (res) {
    if (helper.checkAccessToken(res) ) {
      $(".userEmail").text(res.store.user.email);
    }
  });
});