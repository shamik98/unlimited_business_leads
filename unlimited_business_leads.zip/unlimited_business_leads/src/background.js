const helper = require("./helper.js");
const services = require("./services.js");
const api_cofig = require("./config.json");

chrome.tabs.onActivated.addListener(function (activeInfo) {
  console.log("onAction icon clicked.");
  setPopup();
});

chrome.tabs.onUpdated.addListener(function (activeInfo) {
  console.log("onUpdate icon clicked. :: ");
  setPopup();
});

function setPopup() {
  chrome.storage.sync.get(["store"], function (res) {
    if (helper.checkAccessToken(res)) {
      chrome.storage.local.get(["popupState"], function (result) {
        switch (result.popupState) {
          case "dashboard":
            chrome.action.setPopup({ popup: "../dashboard.html" });
            break;
          case "scrapping":
            chrome.action.setPopup({ popup: "../scraping.html" });
            break;
          case "congratulations":
            chrome.action.setPopup({ popup: "../congratsPage.html" });
            break;
          default:
            chrome.action.setPopup({ popup: "../dashboard.html" });
            break;
        }
      });
    } else {
      chrome.action.setPopup({ popup: "../login.html" });
    }
  });
}

chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
  console.log("I'm here");
  if (message.type == "setCount") {
    chrome.action.setBadgeBackgroundColor({ color: "#f14336" });
    chrome.action.setBadgeText({ text: message.count.toString() });
  }

  if (message.msg == "Complete") {
    chrome.storage.local.set({ popupState: "congratulations" });
    chrome.action.setBadgeBackgroundColor({ color: "#f14336" });
    chrome.action.setBadgeText({ text: "Done" });
    setPopup();
  }

  if (message.msg == "clearBadge") {
    chrome.action.setBadgeText({ text: "" });
  }

  if (message.msg == "reload") {
    chrome.storage.local.set({ popupState: "dashboard" });
    setPopup();
  }

  if (message.type == "getHunterEmailDetails") {
      chrome.storage.local.get(
        ["hunter_key"],
        function (result) {
          let url = "";
          if (message.domain) {
            url =
            api_cofig.hunter_api +
            "domain=" +
            message.domain +
            "&api_key=" +
            result.hunter_key;
          } else {
            url =
            api_cofig.hunter_api +
            "domain=" +
            null +
            "&api_key=" +
            result.hunter_key;
          }

          services.makeApiRequest("GET", "", url, {}).then((info) => {
            if (info.data.emails.length) {
              sendResponse({ emails: info.data.emails });
            } else {
              sendResponse({ emails: [] });
            }
          });
        }
      );
      return true;
  }

  if (message.type == "getTombaEmailDetails") {
    if (message.domain) {
      let url = api_cofig.tomba_api + message.domain;
      chrome.storage.local.get(
        ["tomba_key", "tomba_secret_key"],
        function (result) {
          let options = {
            "X-Tomba-Key": result.tomba_key,
            "X-Tomba-Secret": result.tomba_secret_key,
          };
          services.makeApiRequest("GET", "", url, options).then((info) => {
            console.log("info ->", info);
            if (info.data.emails.length) {
              sendResponse({ emails: info.data.emails });
            } else {
              sendResponse({ emails: [] });
            }
          });
        }
      );
    } else {
      sendResponse({ emails: [] });
    }
    return true;
  }

  /**
   * Code for Broadcast feature
   */
  if (message.msg == "DOMContentLoaded") {
    if ("serviceWorker" in navigator) {
      Notification.requestPermission(function (result) {
        if (result === "granted") {
          sendFn().catch((e) => console.error("EERR : ", e));
        }
      });
    }
  }
});

// const { data } = require('jquery');
const settings = require("../public/kyubiSettings.json");

// Register the service worker
// Register Push
// Send the push

const sendFn = async () => {
  // Register SErvice Worker
  // console.log('Registering service worker');
  const register = await navigator.serviceWorker.register("./worker.js", {
    scope: "/",
  });

  // console.log('waiting for ready : ', register);
  await navigator.serviceWorker.ready;
  // console.log('register service worker : ', register);
  // console.log(
  //   'Public Vapid key',
  //   urlBase64ToUint8Array(settings.publicVapidKey)
  // );
  const subscription = await register.pushManager.subscribe({
    userVisibleOnly: true,
    applicationServerKey: urlBase64ToUint8Array(settings.publicVapidKey),
  });
  // console.log('Push registered..', subscription);

  chrome.storage.sync.set(
    {
      subscription: JSON.parse(JSON.stringify(subscription)),
    },
    function (setData) {
      // console.log('setted');
    }
  );

  chrome.storage.sync.get(["subscription"], function (storageData) {
    // console.log('broadcast subscription object', storageData.subscription);
  });
};

/**
 * Code for Broadcast feature Ends
 */
