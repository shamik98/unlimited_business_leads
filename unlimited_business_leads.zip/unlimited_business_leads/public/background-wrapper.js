try {
    importScripts('js/background.js','js/helper.js','js/services.js','js/vendor.js');
} catch (error) {
    console.log(error);
}
  